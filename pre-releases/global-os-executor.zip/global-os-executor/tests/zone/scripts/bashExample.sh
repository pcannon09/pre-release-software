echo "Hello world! How are you?"

sleep 1

echo "This is supposed to be executed by a PGOE file"

answer=""

echo "Do you wanna quit this program? Y/n?"

read -n answer
if [[ "$answer" == "y" ]] || [[ "$answer" == "Y" ]] || [[ "$answer" == "yes" ]]; then
	echo "Bye, random user"

	exit 0

elif [[ "$answer" == "n" ]] || [[ "$answer" == "N" ]] || [[ "$answer" == "no" ]]; then
	echo "Starting loop in"
	echo "3"
	sleep 1

	echo "2"
	sleep 1

	echo "1"
	sleep 1

	while [ true ]; do
		echo "Do CTRL + C to exit..."
	done

else
	echo "Don't know what you mean, I guess i'll leave"
	echo "Bye, random user"

	exit 1
fi

