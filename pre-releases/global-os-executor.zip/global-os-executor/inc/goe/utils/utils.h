#ifndef INCLUDE_UTILS_UTILS_H_
#define INCLUDE_UTILS_UTILS_H_

#include "../../../vendor/cvec/inc/cvec/cvec.h"
#include "../../../vendor/cstr/inc/cstr/cstr.h"

const char *goe_utils_charToCharPtr(const char _ch);
const char *goe_utils_cvecGetOrEmpty(const CVEC *_vec, const int _pos);
const char *goe_utils_getCurrentDir(void);
const char *goe_utils_createParserLexError(const char *_name, const char *_message);

char *goe_utils_substr(const char *_str, size_t _start, size_t _len);

bool goe_utils_isPrefixWith(const char *_original, const char *_prefix, const int size);

size_t goe_utils_countChar(const char *_str, const char ch);

CSTR goe_utils_charToCSTR(const char *_original);

#endif  // INCLUDE_UTILS_UTILS_H_
