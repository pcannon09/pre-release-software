#ifndef INCLUDE_UTILS_GOE_WESI_H_
#define INCLUDE_UTILS_GOE_WESI_H_

#include "../../../../vendor/cvec/inc/cvec/cvec.h"

enum GOE_WESI_Type
{
	GOE_WESI_Type_None,
	GOE_WESI_Type_Error,
	GOE_WESI_Type_Warning,
};

typedef struct
{
 	enum GOE_WESI_Type type;

	int code;
	int index; // Shouldn't be touched, will be overwriten

	char *message;
	char *help;
} GOE_WESI_Info;

void goe_wesi_init(void);
void goe_wesi_push(GOE_WESI_Info _push, const bool _print);
void goe_wesi_destroy(void);
bool goe_wesi_hasWE(void);
void goe_wesi_throw(const enum GOE_WESI_Type _type);

const char *goe_wesi_typeToStr(const enum GOE_WESI_Type _type);

#endif  // INCLUDE_UTILS_GOE_WESI_H_
