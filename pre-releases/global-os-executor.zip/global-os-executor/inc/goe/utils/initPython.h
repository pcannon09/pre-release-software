#ifndef INCLUDE_UTILS_INITPYTHON_H_
#define INCLUDE_UTILS_INITPYTHON_H_

#include <python3.13/Python.h> // TODO: FIX TO WORK WITH ANY VERSION

int goepy_initPythonSys(const char *_cwd);
int goepy_initMod(PyObject **mod, const char *_mName);

PyObject *goepy_getFunc(PyObject *mod, const char *_fname);

#endif  // INCLUDE_UTILS_INITPYTHON_H_
