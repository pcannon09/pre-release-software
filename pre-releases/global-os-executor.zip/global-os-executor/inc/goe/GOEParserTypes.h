#ifndef INCLUDE_GOE_GOEPARSERTYPES_H_
#define INCLUDE_GOE_GOEPARSERTYPES_H_

#include "GOEgeneralTypes.h"

#include "../../vendor/cstr/inc/cstr/cstr.h"
#include "../../vendor/cvec/inc/cvec/cvec.h"

enum GOEParse_LexType
{
	GOEParse_LexType_NONE,
	GOEParse_LexType_STRING
};

GOE_Declare_Pair(CVEC, enum GOEParse_LexType, TypeDataParams);
GOE_Declare_Pair(int, int, Int);

typedef struct
{
	const char *message;

	CSTR fullError;

	int code;
} GOEParser_ErrorData;

typedef struct
{
	bool insideBlock;
	bool insideString;
	bool isKeywordProcessing;
} GOEParser_TypeStatus;

typedef struct
{
	bool success;

	int code;
	int currentLine;
	int initialIteratorLoop;

 	GOEParser_TypeStatus typeStatus;

	GOE_PairInt startEndBlockRange;
	GOE_PairInt startEndBlockLineRange;

	const char *codeMsg;
	const char *fullFile;

	char *openSection;
	char *closeSection;

	char *modFileContent;
	char *name;
} GOEParser_CallDataInfo;

typedef struct
{
	int code;
	int initialIteratorLoop;

	size_t tokCount;

	unsigned int requestCode;
	GOE_PairInt charsIgnore; // Should have request code `GOE_PARSER_CODE_DATA_REMOVE_LINES`

	char *modFile;

	const char *fileContent;
	const char *command;
	const char *message;
} GOEParser_CallDataSender;

typedef struct
{
	const char *id;
	const char *keyword;

	CVEC typeID;

	GOE_PairTypeDataParams params;

	GOEParser_CallDataSender (*call)(GOEParser_CallDataInfo, GOE_PairTypeDataParams);
} GOEParser_TypeData;

#endif  // INCLUDE_GOE_GOEPARSERTYPES_H_

