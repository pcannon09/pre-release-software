#ifndef INCLUDE_GOE_GOEPOSTDEFINES_H_
#define INCLUDE_GOE_GOEPOSTDEFINES_H_

#include "GOEpredefines.h"

#if defined(GOE_OS_WIN32)
# 	define GOE_OS_STRING_NAME "win"
# 	define GOE_sys_getcwd 	_getcwd // Need to include <direct.h>
#elif defined(GOE_OS_LINUX)
# 	define GOE_OS_STRING_NAME 			"linux"
# 	define GOE_sys_getcwd 	getcwd // Need to include <unistd.h>
#elif defined(GOE_OS_UNIX)
# 	define GOE_OS_STRING_NAME "unix"
#elif defined(GOE_OS_MACOS)
# 	define GOE_OS_STRING_NAME "macos"
#elif defined(GOE_OS_FREEBSD)
# 	define GOE_OS_STRING_NAME "freebsd"
#else
# 	define GOE_OS_STRING_NAME "unknown"
#endif // GOE_OS_WIN32

#endif  // INCLUDE_GOE_GOEPOSTDEFINES_H_
