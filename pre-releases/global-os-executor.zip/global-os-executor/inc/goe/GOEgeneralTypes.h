#ifndef INCLUDE_GOE_GOEGENERALTYPES_H_
#define INCLUDE_GOE_GOEGENERALTYPES_H_

#define GOE_Declare_Pair(type, type2, id) \
	typedef struct \
	{ \
		type first; \
		type2 second; \
	} GOE_Pair##id

#endif  // INCLUDE_GOE_GOEGENERALTYPES_H_
