// IMPORTANT:
// CHECK /src/defines/userDefines.c for more information ('/' refering from project root)

#ifndef INCLUDE_DEFINES_USERDEFINES_H_
#define INCLUDE_DEFINES_USERDEFINES_H_

#include "../GOEParserTypes.h"

// DO NOT MODIFY THIS TYPE
// Adding anything else won't do anything
// Deleting any of the types won't compile the code
typedef struct
{
	int code;

	const char *message;
	const char *extraMsg;
	const char *help;
} GOE_UserDefError;

int goe_userDef_caller(const GOEParser_CallDataSender _callData);
GOE_UserDefError goe_userDef_callerError(const int _code);

#endif  // INCLUDE_DEFINES_USERDEFINES_H_
