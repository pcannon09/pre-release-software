/**
 * GOEpredefines.h - pcannonProjectStandards
 * Predefines for C and C++ projects
 * STD Information: 20250723 - 1.0S
 */

#ifndef INCLUDE_GOE_GOEPREDEFINES_H_
#define INCLUDE_GOE_GOEPREDEFINES_H_

// Project setup
#define GOE_DEFAULT_C_STD			201111L

// Versioning
#define GOE_VERSION_MAJOR            0
#define GOE_VERSION_MINOR            0
#define GOE_VERSION_PATCH            0

#define GOE_VERSION_STD              0

// Version states:
// * dev
// * beta
// * build
#define GOE_VERSION_STATE          "dev"

#define GOE_VERSION                ((GOE_VERSION_MAJOR<<16)|(GOE_VERSION_MINOR<<8)|(GOE_VERSION_PATCH)|(GOE_VERSION_STATE << 24))

#define GOE_VERSION_CHECK(GOE_VERSION_MAJOR, GOE_VERSION_MINOR, GOE_VERSION_PATCH, GOE_VERSION_STATE) \
    (((GOE_VERSION_MAJOR)<<16)|((GOE_VERSION_MINOR)<<8)|(GOE_VERSION_PATCH)|((GOE_VERSION_STATE) << 24))

// Macro utils
#define GOE_STRINGIFY(x) #x
#define GOE_TOSTRING(x) GOE_STRINGIFY(x)

#ifndef GOE_DEV
#   define GOE_DEV 1
#endif // GOE_DEV

#ifndef GOE_USER_DEFINES
#	define GOE_USER_DEFINES 0
#endif //

#ifdef WIN32
#	define GOE_OS_WIN32
#elif defined(__APPLE__) || defined(__MACH__) || defined(Macintosh)
#	define GOE_OS_MACOS
#elif defined(__linux__)
#	define GOE_OS_LINUX
#elif defined(__unix) || defined(__unix__)
#	define GOE_OS_UNIX
#elif defined(__FreeBSD__)
#	define GOE_OS_FREEBSD
#else
#	warning Current platform *might* not supported
#endif // defined(WIN32) // Platform check

#ifdef GOE_sys_strdup
# 	undef GOE_sys_strdup
#endif

#if defined(GOE_OS_WIN32)
# 	define GOE_sys_strdup 		_strdup
#else
# 	ifdef _POSIX_C_SOURCE 
# 		undef _POSIX_C_SOURCE 
# 	endif
# 	define _POSIX_C_SOURCE 200809L
# 	define GOE_sys_strdup 		strdup
#endif // defined(GOE_OS_WIN32)

#define GOE_FREE(_x) \
	if (_x != NULL) { free(_x); _x = NULL; }

#define GOE_GET_FREE(_x) \
	void *get = _x; \
	GOE_FREE(get)

#define GOE_FAIL 	 		-1
#define GOE_SUCCESS 		0
#define GOE_MOD_FAIL 		1

#endif  // INCLUDE_GOE_GOEPREDEFINES_H_

