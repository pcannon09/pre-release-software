#ifndef INCLUDE_GOE_GOECONF_H_
#define INCLUDE_GOE_GOECONF_H_

#include <stdbool.h>

#include "../../vendor/cvec/inc/cvec/cvec.h"

typedef struct
{
	bool defineTypes;
	bool directShowError;

	CVEC typeID;

	char openSection;
	char closeSection;
} GOEConf;

#endif  // INCLUDE_GOE_GOECONF_H_
