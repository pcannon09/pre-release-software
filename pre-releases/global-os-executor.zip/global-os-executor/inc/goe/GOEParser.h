#ifndef INCLUDE_GOE_GOEPARSER_H_
#define INCLUDE_GOE_GOEPARSER_H_

#include "GOEConf.h"
#include "GOEParserTypes.h"

#define GOE_PARSER_CODE_FATAL   					-1
#define GOE_PARSER_CODE_DATA_NONE   				0
#define GOE_PARSER_CODE_DATA_MOD_FILE 			 	1
#define GOE_PARSER_CODE_DATA_OUT 					2

#define GOE_PARSERERR_UNKNOWN 	 					-1
#define GOE_PARSERERR_NONE 		 					0
#define GOE_PARSERERR_UNKNOWN_KW 					1
#define GOE_PARSERERR_VALIDATION_FAIL 				2
#define GOE_PARSERERR_NOEND 						3
#define GOE_PARSERERR_NOSTART 						4

GOE_Declare_Pair(GOEParser_TypeData, bool, TypeDataTransfer);
GOE_Declare_Pair(int, const char*, Identifier);
GOE_Declare_Pair(CVEC, char*, SplitData);
GOE_Declare_Pair(bool, GOEParser_TypeData, KeywordRegistry);
GOE_Declare_Pair(CVEC, bool, CVECCheck);

typedef struct GOEParser_LexData
{
	bool insideBlock;
	bool insideString;
	bool processingBlockParams;
} GOEParser_LexData;

typedef struct GOEParser 
{
	CVEC registeredTypeData;
	CVEC registeredTypeDataStrKw;
	CVEC typeID;
	CVEC preLexIdentifiers;

	GOEConf config;
	GOEParser_TypeData typeData;
	GOEParser_ErrorData errorData;
} GOEParser;

enum GOEParser_Types
{
	None,
	GOEParser_String,
	GOEParser_LexIdentifier,
};

void goe_parser_setDefaults(void);
void goe_parser_collapseToString(GOE_PairTypeDataParams *_params, int _start, int _end);

GOE_PairCVECCheck goe_parser_parseParams(CSTR fileDataResult, const GOE_PairKeywordRegistry tokenValidation, GOE_PairTypeDataParams *dataParams,
		const int accumulatedOpenSectionPos, const int accumulatedCloseSectionPos, const char *closeSectionChar, GOEParser_LexData *lexData);

int goe_parser_destroy(GOEParser parser);

size_t goe_parser_calculateToksAB(const char *_fileData, const size_t pa, const size_t pb);

GOEParser goe_parser_preinit(void);
GOEParser goe_parser_init(void);

GOE_PairKeywordRegistry goe_parser_isKeywordRegistered(const GOEParser *_parser, const char *_get);

GOEParser_ErrorData goe_parser_lex(GOEParser _parser, const char *_fileData);
GOEParser_CallDataInfo goe_parser_predefAction(int _code, const GOEParser_CallDataSender _sender);

// PRIVATE
GOE_PairSplitData __goe_parser_lexSplitSetup(const GOEParser _parser, CVEC *_vec, char *_fileData);

#endif  // INCLUDE_GOE_GOEPARSER_H_
