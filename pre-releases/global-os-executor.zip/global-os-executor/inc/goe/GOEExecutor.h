#ifndef INCLUDE_GOE_GOEEXECUTOR_H_
#define INCLUDE_GOE_GOEEXECUTOR_H_

const char *goe_executor_defaultShell();

unsigned int goe_executor_exec(const char *_shell, const char *_command);

#endif  // INCLUDE_GOE_GOEEXECUTOR_H_
