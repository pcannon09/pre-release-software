#ifndef INCLUDE_DEFAULTS_GOEDEFAULTTYPES_H_
#define INCLUDE_DEFAULTS_GOEDEFAULTTYPES_H_

#include "../GOEParserTypes.h"

enum GOE_ExBool
{
	GOE_EB_False,
	GOE_EB_True,
	GOE_EB_Null
};

GOEParser_CallDataSender goe_defTypes_comment(const GOEParser_CallDataInfo dataInfo, const GOE_PairTypeDataParams params);
GOEParser_CallDataSender goe_defTypes_print(const GOEParser_CallDataInfo dataInfo, const GOE_PairTypeDataParams params);
GOEParser_CallDataSender goe_defTypes_exec(const GOEParser_CallDataInfo dataInfo, const GOE_PairTypeDataParams params);

#endif  // INCLUDE_DEFAULTS_GOEDEFAULTTYPES_H_
