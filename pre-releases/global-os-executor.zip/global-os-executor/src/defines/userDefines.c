// THIS IS A USER DEFINED FILE, BE FREE TO MODIFY THIS FILE TO YOUR PREFERENCE
// This file will be included if `GOE_USER_DEFINES` is defined when building

#include "../../inc/goe/GOEParserTypes.h"
#include "../../inc/goe/defines/userDefines.h"

// * This is the main caller where depending on the command you *should*
// 	 call a specific function
int goe_userDef_caller(const GOEParser_CallDataSender _callData)
{
	return -1;
}

// Default caller error if something wrong happens
// YOU SHOULD NOT REMOVE OR MODIFY CODE (-1)
GOE_UserDefError goe_userDef_callerError(const int _code)
{
	GOE_UserDefError ret;

	if (_code == 0) ret.code = _code;
	else if (_code == -1)
	{
		ret.message = "Modify the internal code to customize GOE, if you don't want to customize, do not define GOE_USER_DEFINES macro when building";
		ret.help = "Go to `/inc/goe/defines/userDefines.h` and `/src/defines/userDefines.c` for more information";
		ret.code = _code;
	}

	return ret;
}

