#include <stdio.h>
#include <unistd.h>

#include "../inc/goe/GOEParser.h"

int main(void)
{
	// {
	//    	char *wd = (char*)goe_utils_getCurrentDir();
	//
	//    	goepy_initPythonSys(wd);
	//
	//    	GOE_FREE(wd);
	// }
	//
	//    PyObject *calcMod = NULL;
	//
	//    if (goepy_initMod(&calcMod, "src.python.utils.goepy_callTest") != GOE_SUCCESS)
	//        return 1;
	//
	//    PyObject *func = goepy_getFunc(calcMod, "goepy_callTests_add");
	//
	//    if (!func) return 1;
	//
	//    PyObject *args = Py_BuildValue("(ii)", 2, 2);
	//    PyObject *result = PyObject_CallObject(func, args);
	//
	//    Py_DECREF(args);
	//    Py_DECREF(func);
	//    Py_DECREF(calcMod);
	//
	//    if (!result)
	//    {
	//        PyErr_Print();
	//
	//        return 1;
	//    }
	//
	//    Py_DECREF(result);
	//
	//    Py_Finalize();
	//
	// return 0;

	CSTR fileContent = cstr_init();

	const char *fileConfPath = "./tests/zone/file1.pgoe";

	{
		FILE *file = fopen(fileConfPath, "r");

		if (!file)
		{
			fprintf(stderr, "Could not open file `%s`. Wrong path?\n", fileConfPath);

			cstr_destroy(&fileContent);

			return 1;
		}

		char ch;

		while ((ch = fgetc(file)) != EOF)
		{
			char tmpCh[2] = { ch, '\0' };

			cstr_add(&fileContent, tmpCh);
		}

		fclose(file);
	}

	goe_parser_setDefaults();

	GOEParser mainParser = goe_parser_init();

	GOEParser_ErrorData error = goe_parser_lex(mainParser, fileContent.data);

	printf("RET CODE: %i\n", error.code);
	printf("MESSAGE: %s\n", error.message);

	goe_parser_destroy(mainParser);
	cstr_destroy(&fileContent);

	return 0;
}

