#include <unistd.h>
#include <stdio.h>

#ifdef GOE_OS_WIN32
# 	include <process.h>
# 	include <windows.h>
# 	define __GOE_EXEC_COMMAND(_cmd) 		_popen(_cmd, "r")
#else
# 	define __GOE_EXEC_COMMAND(_cmd) 		{ }
# 	include <unistd.h>
# 	include <sys/wait.h>
# 	include <stdlib.h>
#endif // ifdef GOE_OS_WIN32

const char *goe_executor_defaultShell()
{
#ifndef GOE_OS_WIN32
	return getenv("SHELL");
#else
	return getenv("COMSPEC")
#endif // ifndef GOE_OS_WIN32
}

unsigned int goe_executor_exec(const char *_shell, const char *_command)
{
#ifndef GOE_OS_WIN32
	pid_t pid = fork();

	if (pid < 0)
	{
		perror("Fork failiure");

		return 1;
	}

	if (pid == 0)
	{
		char *args[] = { (char*)_shell, "-c", (char*)_command, NULL };

		execv(args[0], args);
		perror("Execution failiure");
		exit(1);

		return 2;
	}

	else wait(NULL);

	return 0;

#else // WINDOWS ONLY
	FILE *fp = __GOE_EXEC_COMMAND(_command);

	if (!fp) perror("Command execution failed");
	else 	_pclose(fp);
#endif // ifndef GOE_OS_WIN32
}
