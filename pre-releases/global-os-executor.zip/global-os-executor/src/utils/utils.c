#include "../../inc/goe/GOEpredefines.h"
#include "../../inc/goe/GOEpostdefines.h"
#include "../../inc/goe/utils/utils.h"

#include "../../vendor/cvec/inc/cvec/cvec.h"
#include "../../vendor/cstr/inc/cstr/cstr.h"

#include <stdlib.h>

#ifdef GOE_OS_LINUX
# 	include <unistd.h>
#endif

const char *goe_utils_createParserLexError(const char *_name, const char *_message)
{
	CSTR str = cstr_init();
	char *ret;

	// Format should be like this example:
	// ERROR: [ NAME ]: Message
	cstr_set(&str, "ERROR [ ");
	cstr_add(&str, _name);
	cstr_add(&str, " ]: ");
	cstr_add(&str, _message);

	ret = str.data;

	return ret;
}

const char *goe_utils_charToCharPtr(const char _ch)
{
	char *modCh = malloc(2);

	if (!modCh)
		return NULL;

	modCh[0] = _ch;
	modCh[1] = '\0';
	
	return modCh;
}

const char *goe_utils_cvecGetOrEmpty(const CVEC *_vec, const int _pos)
{
	const char *item = cvec_get(_vec, _pos);

	if (!item)
		return "";

	return item;
}

const char *goe_utils_getCurrentDir(void)
{ return GOE_sys_getcwd(NULL, 0); }

bool goe_utils_isPrefixWith(const char *_original, const char *_prefix, const int size)
{
    if (size > strlen(_original)) return false;

    return strncmp(_original, _prefix, size) == 0;
}

char *goe_utils_substr(const char *_str, size_t _start, size_t _len)
{
	CSTR str;
	cstr_initCopy(&str, _str);
	
	cstr_substr(&str, _start, _len); // Ignore return code `1` (or others) by not checking with if statment
									 // can be "dangerous", but can be left untouched as for now
									 // BUG: in CSTR 1.1.0 - Need to fix lib

	char *data = GOE_sys_strdup(str.data);

	cstr_destroy(&str);

	return data;
}

size_t goe_utils_countChar(const char *_str, const char ch)
{
	if (!_str)
		return 0;

	size_t foundChs = 0;

	for (size_t i = 0 ; i < strlen(_str) ; i++)
	{ if (_str[i] == ch) foundChs++; }

	return foundChs;
}

CSTR goe_utils_charToCSTR(const char *_original)
{
	CSTR str = cstr_init();
	
	cstr_set(&str, _original);

	return str;
}

