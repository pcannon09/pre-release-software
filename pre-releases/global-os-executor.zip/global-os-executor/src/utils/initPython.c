#include <unistd.h>
#include <python3.13/Python.h> // TODO: FIX TO WORK WITH ANY VERSION

#include "../../inc/goe/GOEpredefines.h"
#include "../../vendor/cstr/inc/cstr/cstr.h"

int goepy_initPythonSys(const char *_cwd)
{
	Py_Initialize();

	CSTR fullPythonSetup = cstr_init();

	cstr_add(&fullPythonSetup, "import sys\n");
	cstr_add(&fullPythonSetup, "sys.path.insert(0, \"");
	cstr_add(&fullPythonSetup, _cwd);
	cstr_add(&fullPythonSetup, "\")\n");

	PyRun_SimpleString(fullPythonSetup.data);

	cstr_destroy(&fullPythonSetup);

	return GOE_SUCCESS;
}

int goepy_initMod(PyObject **mod, const char *_mName)
{
	PyObject *modCalc = PyUnicode_FromString(_mName);
	*mod = PyImport_Import(modCalc);

	Py_DECREF(modCalc);

	if (!*mod)
	{
		PyErr_Print();

		return GOE_MOD_FAIL;
	}

	return GOE_SUCCESS;
}

PyObject *goepy_getFunc(PyObject *mod, const char *_fname)
{
    PyObject *func = PyObject_GetAttrString(mod, _fname);

    if (!func || !PyCallable_Check(func))
    {
        PyErr_Print();
        Py_XDECREF(func);

        return NULL;
    }

    return func;
}

