#include "../../../inc/goe/GOEpredefines.h"

#include "../../../inc/goe/utils/impl/GOE_WESI.h"

static int errorIndex = 0;
static int warningIndex = 0;
static int otherIndex = 0;

CVEC errorVec;
CVEC warningVec;

void goe_wesi_init(void)
{
	errorVec = cvec_init(-1, sizeof(GOE_WESI_Info));
	warningVec = cvec_init(-1, sizeof(GOE_WESI_Info));
}

void goe_wesi_throw(const enum GOE_WESI_Type _type)
{
    const GOE_WESI_Info *push = {0};

    for (size_t i = 0 ; i < errorVec.size ; i++)
    {
        if (_type == GOE_WESI_Type_Error) push = cvec_get(&errorVec, i);
        else if (_type == GOE_WESI_Type_Warning) push = cvec_get(&warningVec, i);

        if (!push) continue;

        printf("WESI (Warning Error System Integration)\n");
        printf("WESI TYPE: %s\n", goe_wesi_typeToStr(push->type));
        printf("WESI INDEX: %i\n", push->index);
        printf("WESI CODE: %i\n", push->code);

        if (push->message != NULL) printf("WESI MESSAGE: %s\n", push->message);
        if (push->help != NULL) printf("WESI HELP: %s\n", push->help);
    }
}

bool goe_wesi_hasWE(void)
{
	unsigned int counter = 0;

	if (errorVec.size > 0) counter++;
	if (warningVec.size > 0) counter++;

	if (counter > 0) return true;

	return false;
}

void goe_wesi_push(GOE_WESI_Info _push, const bool _print)
{
	if (_push.type == GOE_WESI_Type_Error)
	{
		errorIndex++;
		_push.index = errorIndex;

		cvec_push(&errorVec, GOE_WESI_Info, _push);
	}

	else if (_push.type == GOE_WESI_Type_Warning)
	{
		warningIndex++;
		_push.index = warningIndex;
		
		cvec_push(&errorVec, GOE_WESI_Info, _push);
	}

	else if (_push.type == GOE_WESI_Type_None) { }

	else
	{
		otherIndex++;
		_push.index = otherIndex;

		cvec_push(&errorVec, GOE_WESI_Info, _push);
	}

	if (!_print) return;

	printf("WESI (Warning Error System Integration)\n");
	printf("WESI TYPE: %s\n", goe_wesi_typeToStr(_push.type));
	printf("WESI INDEX: %i\n", _push.index);
	printf("WESI CODE: %i\n", _push.code);
	printf("WESI MESSAGE: %s\n", _push.message);
	printf("WESI HELP: %s\n", _push.help);
}

void goe_wesi_destroy(void)
{
	// Errors
    for (size_t i = 0; i < errorVec.size; ++i)
    {
        GOE_WESI_Info *info = cvec_get(&errorVec, i);

        if (!info) continue;

        { GOE_FREE(info->message); }
        { GOE_FREE(info->help); }
    }

	// Warnings
    for (size_t i = 0; i < warningVec.size; ++i)
    {
        GOE_WESI_Info *info = cvec_get(&warningVec, i);

        if (!info) continue;

        { GOE_FREE(info->message); }
        { GOE_FREE(info->help); }
    }

    // Destroy the vectors themselves
    cvec_destroy(&errorVec);
    cvec_destroy(&warningVec);
}

const char *goe_wesi_typeToStr(const enum GOE_WESI_Type _type)
{
	switch (_type)
	{
		case GOE_WESI_Type_None: 				return "none";
		case GOE_WESI_Type_Error: 				return "error";
		case GOE_WESI_Type_Warning: 			return "warning";
		default: 								return "UNKNOWN";
	}
}

