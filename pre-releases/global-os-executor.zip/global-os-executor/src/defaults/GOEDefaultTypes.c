#include "../../inc/goe/GOEParser.h"
#include "../../inc/goe/utils/utils.h"

#include "../../inc/goe/defaults/GOEDefaultTypes.h"

GOEParser_CallDataSender goe_defTypes_comment(const GOEParser_CallDataInfo dataInfo, const GOE_PairTypeDataParams params)
{
	GOEParser_CallDataSender sender = {0};
	CSTR modifiedFile; cstr_initCopy(&modifiedFile, dataInfo.fullFile);

	const size_t commentSectionPos = cstr_find(&modifiedFile, dataInfo.name);

	if (commentSectionPos != CSTR_NPOS)
	{
		const size_t openSectionPos = cstr_findFrom(&modifiedFile, dataInfo.openSection, commentSectionPos - 1);
		const size_t closeSectionPos = cstr_findFrom(&modifiedFile, dataInfo.closeSection, openSectionPos) + 1;

		if (closeSectionPos == CSTR_NPOS)
		{
			CSTR messageCSTR = cstr_init();

			sender.message = goe_utils_createParserLexError(dataInfo.name, "Could not find an end of the file due to the closing section not being present");
			sender.code = GOE_PARSERERR_NOEND;

			cstr_destroy(&messageCSTR);

			return sender;
		}

		else if (openSectionPos == CSTR_NPOS)
		{
			CSTR messageCSTR = cstr_init();

			sender.message = goe_utils_createParserLexError(dataInfo.name, "Could not find an end of the file due to the opening section not being present");
			sender.code = GOE_PARSERERR_NOSTART;

			cstr_destroy(&messageCSTR);

			return sender;
		}

		// Main logic goes here

		cstr_erase(&modifiedFile, openSectionPos, closeSectionPos);

		sender.charsIgnore.first = openSectionPos;
		sender.charsIgnore.second = closeSectionPos;
		sender.requestCode = GOE_PARSER_CODE_DATA_MOD_FILE;
		sender.modFile = modifiedFile.data;
		sender.code = 0;
	}

	else
	{
		sender.message = "Did not find any comment section";
		sender.code = -1;
	}

	return sender;
}

GOEParser_CallDataSender goe_defTypes_print(const GOEParser_CallDataInfo dataInfo, const GOE_PairTypeDataParams params)
{
	GOEParser_CallDataSender sender = {0};

	sender.initialIteratorLoop = dataInfo.initialIteratorLoop;
	sender.requestCode = GOE_PARSER_CODE_DATA_OUT;

	CSTR toPrint = cstr_init();
	
	if (params.second == GOEParse_LexType_NONE)
	{
		for (size_t i = 0 ; i < params.first.size ; i++)
		{
			char **index = cvec_get(&params.first, i);

			if (!index) continue;

			cstr_add(&toPrint, *index);
		}
	}

	else if (params.second == GOEParse_LexType_STRING)
	{
		CSTR indexCSTR = cstr_init();

		for (size_t i = 0 ; i < params.first.size ; i++)
		{
			char **index = cvec_get(&params.first, i);

			if (!index) continue;

			cstr_set(&indexCSTR, *index);
			cstr_add(&toPrint, indexCSTR.data);
			cstr_erase(&indexCSTR, 0, 1);
			cstr_erase(&indexCSTR, indexCSTR.len - 1, 1);
		}

		cstr_destroy(&indexCSTR);
	}

	sender.charsIgnore.second = toPrint.len;
	sender.code = 0;

	printf("%s\n", toPrint.data);

	cstr_destroy(&toPrint);

	return sender;
}

GOEParser_CallDataSender goe_defTypes_exec(const GOEParser_CallDataInfo dataInfo, const GOE_PairTypeDataParams params)
{
	GOEParser_CallDataSender sender = {0};



	return sender;
}

