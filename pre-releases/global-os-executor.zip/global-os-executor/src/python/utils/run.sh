if [[ "$1" == "clean" ]]; then
	rm -rf __pycache__

else
	python goepy_tests.py
fi

