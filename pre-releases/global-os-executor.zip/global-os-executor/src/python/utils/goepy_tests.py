import calc
from impl import GOEPY_predefines
import sys

if __name__ == "__main__":
	hasError = False
	calculation = calc.goepy_utils_impl_calculate("(2 + 2 / 4) * 10 + 1 + 1 + 0.2")

	if calculation[0] != 0: hasError = True

	GOEPY_predefines.PRINT(calculation[1])

	if not hasError: sys.exit(0)
	else: sys.exit(1)

