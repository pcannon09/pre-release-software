from impl import GOEPY_predefines

def goepy_utils_impl_calculate(_eval):
	FUNCTION_NAME = "goepy_utils_impl_calculate"
	msg = ""
	retCode = 0

	try:
		msg = eval(_eval)

	except Exception as err:
		msg = GOEPY_predefines.goepy_utils_impl_makeError(FUNCTION_NAME, err, _eval, "\n");
		retCode	= 1

	return [ retCode, msg ]

