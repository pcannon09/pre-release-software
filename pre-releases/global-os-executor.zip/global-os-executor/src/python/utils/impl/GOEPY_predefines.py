import sys

def goepy_utils_impl_makeError(_FUNCTION_NAME, _errorMsg, _invok = "", _sep="\n"):
	total = ""

	total += "ERROR: "
	total += _FUNCTION_NAME
	total += "(<" ; total += _invok ; total += ">): "
	total += _sep
	total += str(_errorMsg)

	return total

def PRINT(*str):
	if sys.version_info >= (3, 0):
		print(*str)

	else:
		print *str

