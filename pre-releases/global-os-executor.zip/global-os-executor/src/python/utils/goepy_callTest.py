def goepy_callTests_add(a, b):
	addition = a + b

	print(addition)

	return addition

