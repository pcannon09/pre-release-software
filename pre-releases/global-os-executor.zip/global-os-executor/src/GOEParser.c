#include "../inc/goe/GOEpredefines.h"

#include <stdint.h>

#include "../inc/goe/GOEParser.h"
#include "../inc/goe/defaults/GOEDefaultTypes.h"

#include "../inc/goe/utils/utils.h"

#include "../inc/goe/utils/impl/GOE_WESI.h"

#if GOE_USER_DEFINES
# 	include "../inc/goe/defines/userDefines.h"
#endif

GOEConf goe_parser_overrideConfig;

#define __GOE_AS_NORMAL_LEX_CONTINUE \
	if (accumulatedOpenSectionPos <= 0) { accumulatedOpenSectionPos++; } \
	for (size_t _i = 0 ; _i < freedParsedParams.first.size ; _i++) \
	{ \
		char **freeIndex = cvec_get(&freedParsedParams.first, _i); \
		if (!freeIndex) continue; \
		GOE_FREE(*freeIndex); \
	} \
	cvec_destroy(&freedParsedParams.first)

#define __GOE_PARSER_PROCESS_PARAMS \
	if (lexData.insideBlock && !lexData.processingBlockParams) lexData.processingBlockParams = true;

#define __GOE_PARSER_PARSEPARAMS_NONCONTINUE \
	GOE_FREE(chPtr)

#define __GOE_PARSER_PARSEPARAMS_CONTINUE \
	__GOE_PARSER_PARSEPARAMS_NONCONTINUE; continue

GOE_PairKeywordRegistry goe_parser_isKeywordRegistered(const GOEParser *_parser, const char *_get)
{
    GOE_PairKeywordRegistry kwreg = {0};
    kwreg.first = false;

    for (size_t i = 0; i < _parser->registeredTypeData.size; ++i)
    {
        GOEParser_TypeData *getKw = (GOEParser_TypeData*)cvec_get(&_parser->registeredTypeData, i);

        if (strcmp(getKw->keyword, _get) == 0)
        {
        	kwreg.first = true;
            kwreg.second = *getKw;

            break;
        }
    }

    return kwreg;
}

static bool goe_parser_isTypeRegistered(const GOEParser *_parser, const char *_get)
{
    for (size_t i = 0; i < _parser->config.typeID.size ; ++i)
    {
        GOE_PairIdentifier *reg = cvec_get(&_parser->config.typeID, i);

        if (reg && reg->second && strcmp(reg->second , _get) == 0)
        	return true;
    }

    return false;
}

static bool goe_parser_isPreLexIdentifiersRegistered(const GOEParser *_parser, const char *_get)
{
    for (size_t i = 0; i < _parser->preLexIdentifiers.size ; ++i)
    {
        char **reg = cvec_get(&_parser->preLexIdentifiers, i);

        if (reg && strcmp(*reg, _get) == 0)
        	return true;
    }

    return false;
}

void goe_parser_setDefaults(void)
{
	goe_parser_overrideConfig.typeID = cvec_init(-1, sizeof(GOE_PairIdentifier));

	goe_parser_overrideConfig.defineTypes = true;
	goe_parser_overrideConfig.openSection = '<';
	goe_parser_overrideConfig.closeSection = '>';
 	goe_parser_overrideConfig.directShowError = true;

	// Register string
	{
		GOE_PairIdentifier id;
		id.first = GOEParser_String;
		id.second = "\"";

		cvec_push(&goe_parser_overrideConfig.typeID, GOE_PairIdentifier, id);

		id.first = GOEParser_String;
		id.second = "'";

		cvec_push(&goe_parser_overrideConfig.typeID, GOE_PairIdentifier, id);
	}
}

// SEARCH: init() function
GOEParser goe_parser_init(void)
{
	GOEParser parser;

	goe_wesi_init();

	parser.config = goe_parser_overrideConfig;
	parser.typeID = goe_parser_overrideConfig.typeID;
	parser.registeredTypeData = cvec_init(-1, sizeof(GOEParser_TypeData));
	parser.registeredTypeDataStrKw = cvec_init(-1, sizeof(const char*));
	parser.preLexIdentifiers = cvec_init(-1, sizeof(const char*));

	cvec_push(&parser.preLexIdentifiers, const char*, "!<newline>!");

	if (parser.config.defineTypes)
	{
		// Comment line(s)
		{
			GOEParser_TypeData *data = malloc(sizeof(GOEParser_TypeData));
			data->id = "comment";
			data->keyword = "COMMENT";
			data->call = goe_defTypes_comment;

			cvec_push(&parser.registeredTypeData, GOEParser_TypeData, *data);
			cvec_push(&parser.registeredTypeDataStrKw, char*, (char*)data->keyword);

			GOE_FREE(data);
		}

		// Execute files
		{
			GOEParser_TypeData *data = malloc(sizeof(GOEParser_TypeData));
			data->id = "exec";
			data->keyword = "EXEC";
			data->call = goe_defTypes_exec;

			cvec_push(&parser.registeredTypeData, GOEParser_TypeData, *data);
			cvec_push(&parser.registeredTypeDataStrKw, char*, (char*)data->keyword);

			GOE_FREE(data);
		}

		// Print
		{
			GOEParser_TypeData data;

			data.id = "print";
			data.keyword = "PRINT";
			data.call = goe_defTypes_print;

			cvec_push(&parser.registeredTypeData, GOEParser_TypeData, data);
			cvec_push(&parser.registeredTypeDataStrKw, char*, (char*)data.keyword);
		}
	}

	return parser;
}

// SEARCH: end() | destroy() functions
int goe_parser_destroy(GOEParser parser)
{
	if (goe_wesi_hasWE()) goe_wesi_destroy();

	{
		int cvecEndRetCode = 0;

		if ((cvecEndRetCode = cvec_destroy(&parser.registeredTypeData)) != CVEC_SUCCESS)
			return cvecEndRetCode;

		if ((cvecEndRetCode = cvec_destroy(&parser.registeredTypeDataStrKw)) != CVEC_SUCCESS)
			return cvecEndRetCode;

		if ((cvecEndRetCode = cvec_destroy(& parser.preLexIdentifiers)) != CVEC_SUCCESS)
			return cvecEndRetCode;
	}

	return 0;
}

GOE_PairSplitData __goe_parser_lexSplitSetup(const GOEParser _parser, CVEC *_vec, char *_fileData)
{
	GOE_PairSplitData splitData = {0};

	CSTR fileData; cstr_initCopy(&fileData, _fileData);

	int indexFound = cvec_find(&_parser.preLexIdentifiers, const char*, "!<newline>!");
	const char **newlineGet = cvec_get(&_parser.preLexIdentifiers, indexFound);

	if (newlineGet != NULL) cstr_replaceAll(&fileData, "\n", *newlineGet);

    cvec_split(_vec, (char*)fileData.data, " ");

    _fileData = GOE_sys_strdup(fileData.data);

    cstr_destroy(&fileData);

    splitData.first = *_vec;
    splitData.second = _fileData;

	return splitData;
}

void goe_parser_collapseToString(GOE_PairTypeDataParams *_params, int _start, int _end)
{
	CSTR param = cstr_init();
	GOE_PairTypeDataParams params;
	params.first = cvec_init(-1, sizeof(const char*));

	if (_start < 0) _start = 0;
	if (_end < 0) _end = _params->first.size;

	for (size_t i = _start ; i < _end ; i++)
	{
		char **ch = cvec_get(&params.first, i);

		if (ch) cstr_add(&param, *ch);
	}

	cvec_push(&params.first, const char*, param.data);

	cstr_destroy(&param);

	_params = &params;
}

GOE_PairCVECCheck goe_parser_parseParams(CSTR fileDataResult, const GOE_PairKeywordRegistry tokenValidation, GOE_PairTypeDataParams *dataParams,
		const int accumulatedOpenSectionPos, const int accumulatedCloseSectionPos, const char *closeSectionChar, GOEParser_LexData *lexData)
{
	GOE_PairCVECCheck toFree = {0};
	toFree.first = cvec_init(-1, sizeof(char*));
	toFree.second = true;

	CSTR accumulatedParams = cstr_init(); // Used to get all params as a single string

	// Get every param (of any type) to the substr
	cstr_set(&accumulatedParams, fileDataResult.data);

	if (accumulatedOpenSectionPos == CSTR_NPOS)
	{
		cvec_push(&toFree.first, const char*, goe_utils_createParserLexError("parse params", "Could not find any opening section position for lexer stage"));
		toFree.second = false;

		cstr_destroy(&accumulatedParams);

		return toFree;
	}

	if (accumulatedCloseSectionPos == CSTR_NPOS)
	{
		cvec_push(&toFree.first, const char*, goe_utils_createParserLexError("parse params", "Could not find any closing section position for lexer stage"));
		toFree.second = false;

		cstr_destroy(&accumulatedParams);

		return toFree;
	}

	cstr_substr(&accumulatedParams,
			accumulatedOpenSectionPos + strlen(tokenValidation.second.keyword) + 1,
			accumulatedCloseSectionPos - 1
			);

	while (cstr_startsWith(accumulatedParams, " ") || cstr_startsWith(accumulatedParams, "\t"))
	{ cstr_erase(&accumulatedParams, 0, 1); }

	if (cstr_startsWith(accumulatedParams, "\"") || cstr_startsWith(accumulatedParams, "'"))
		lexData->insideString = true;

	else lexData->insideString = false;

	if (!lexData->insideString)
	{
		dataParams->second = GOEParse_LexType_NONE;

		// Replace and remove necessary
		cstr_replaceAll(&accumulatedParams, "\n", " ");

		// From A -> B to B -> A
		cstr_reverse(&accumulatedParams);

		// Technically `cstr_endsWith()` function, as the function is reversed, it uses `cstr_startsWith()` function

		while (cstr_startsWith(accumulatedParams, " "))
		{ cstr_erase(&accumulatedParams, 0, 1); }

		while (cstr_startsWith(accumulatedParams, closeSectionChar))
		{ cstr_erase(&accumulatedParams, 0, 1); }

		// From B -> A to A -> B
		// Set as normal
		cstr_reverse(&accumulatedParams);

		cvec_split(&dataParams->first, accumulatedParams.data, " ");
	}

	else
	{
    	CSTR current = cstr_init();
    	CVEC dataParamsCpy = cvec_init(-1, dataParams->first.elemLen);

    	cvec_clear(&dataParams->first);

		dataParams->second = GOEParse_LexType_STRING;

    	bool opened = false;

    	char activeQuote = '\0';

    	for (size_t i = 0 ; i < accumulatedParams.len ; i++)
    	{
        	char ch = accumulatedParams.data[i];
        	char *chPtr = (char*)goe_utils_charToCharPtr(ch);

        	// Wait for opening quote
        	if (!opened)
        	{
            	if (ch == '"' || ch == '\'')
            	{
                	opened = true;
                	activeQuote = ch;

                	__GOE_PARSER_PARSEPARAMS_CONTINUE;
            	}

            	__GOE_PARSER_PARSEPARAMS_CONTINUE;
        	}

        	// Inside a string
        	// Count consecutive backslashes
        	size_t backslashCount = 0;

        	for (size_t j = i ; j > 0 ; j--)
        	{
            	if (accumulatedParams.data[j - 1] == '\\')
                	backslashCount++;

            	else break;
        	}

        	bool isEscaped = (backslashCount % 2 == 1);

        	// Handle closing quotes
        	if (ch == activeQuote && !isEscaped)
        	{
        		char *data = GOE_sys_strdup(current.data);

            	cvec_push(&dataParamsCpy, const char*, data);
				cvec_push(&toFree.first, char*, data);

            	cstr_clear(&current);

            	opened = false;
            	activeQuote = '\0';

            	__GOE_PARSER_PARSEPARAMS_NONCONTINUE;

            	break;
        	}

			// Handle backslash collapsing
        	if (ch == '\\')
        	{
            	// Look ahead to count how many total slashes in a row
            	size_t start = i;

            	while (i + 1 < accumulatedParams.len && accumulatedParams.data[i + 1] == '\\')
                	i++;

            	size_t total = (i - start + 1);

            	// For every pair of backslashes, output one backslash to replicate escape collapsing
            	size_t collapseCount = total / 2;

            	for (size_t k = 0 ; k < collapseCount ; k++)
                	cstr_add(&current, "\\");

            	// If odd number, last one is literal backslash
            	if (total % 2 == 1) cstr_add(&current, "\\");

            	__GOE_PARSER_PARSEPARAMS_CONTINUE;
        	}

        	// Normal or escaped literal character
        	cstr_add(&current, chPtr);

        	__GOE_PARSER_PARSEPARAMS_CONTINUE;
    	}

    	// If still open at end, push it anyway
    	if (opened && current.len > 0)
    	{
        	char *data = GOE_sys_strdup(current.data);
        
        	cvec_push(&dataParams->first, const char*, data);
			cvec_push(&toFree.first, char*, data);
        }

		cvec_destroy(&dataParams->first);
		dataParams->first = cvec_initCopy(&dataParamsCpy);

        cvec_destroy(&dataParamsCpy);
    	cstr_destroy(&current);
	}

	cstr_destroy(&accumulatedParams);

	toFree.second = true;

	return toFree;
}

size_t goe_parser_calculateToksAB(const char *_fileData, const size_t pa, const size_t pb)
{
	CVEC totalToks = cvec_init(-1, sizeof(const char*));
	CSTR fileData; cstr_initCopy(&fileData, _fileData);

	cstr_substr(&fileData, pa, pb);

	cvec_split(&totalToks, fileData.data, " \n");

	const size_t size = totalToks.size;

	cstr_destroy(&fileData);
	cvec_destroy(&totalToks);

	return size;
}

// SEARCH: lex() function
GOEParser_ErrorData goe_parser_lex(GOEParser _parser, const char *_fileData)
{
	GOEParser_ErrorData errorData = {0};
	GOEParser_CallDataInfo callDataInfo = {0};
 	GOE_PairTypeDataParams dataParams = {0};
 	GOEParser_LexData lexData = {0};

	dataParams.first = cvec_init(-1, sizeof(const char*));

	errorData.code = 0;

 	GOE_WESI_Info lexError = {0};

	CSTR constantFileData; cstr_initCopy(&constantFileData, _fileData);
	CSTR fileDataResult; cstr_initCopy(&fileDataResult, _fileData); // DO NOT USE THIS OR THE LEXER WILL BE CONFUSED
	CSTR tok = cstr_init(); // Used to change data of token from `tokCh`

	CVEC fileDataResultCVEC = cvec_init(-1, sizeof(const char*));
	CVEC constantFileDataResult;

	cvec_split(&fileDataResultCVEC, fileDataResult.data, " \n");

	constantFileDataResult = cvec_initCopy(&fileDataResultCVEC);

	size_t accumulatedOpenSectionPos = 0;
	size_t accumulatedCloseSectionPos = 0;

	char *openSectionChar = (char*)goe_utils_charToCharPtr(_parser.config.openSection);
	char *closeSectionChar = (char*)goe_utils_charToCharPtr(_parser.config.closeSection);

 	callDataInfo.openSection = openSectionChar;
 	callDataInfo.closeSection = closeSectionChar;

	const size_t openSectionPos = 0;
	const size_t closeSectionPos = tok.len - sizeof(_parser.config.closeSection);

	GOE_PairCVECCheck freedParsedParams;

	for (int i = 0 ; i < fileDataResultCVEC.size ; i++)
	{
		const char **tokCh = cvec_get(&fileDataResultCVEC, i);

		if (!tokCh && !*tokCh) continue;

		if (*tokCh[0] == '\0' || *tokCh[0] == '\n') continue;

		cstr_set(&tok, *tokCh);

		accumulatedOpenSectionPos = cstr_findFrom(&fileDataResult, openSectionChar, accumulatedOpenSectionPos);
		accumulatedCloseSectionPos = cstr_findFrom(&fileDataResult, closeSectionChar, accumulatedCloseSectionPos);

		while (cstr_startsWith(tok, "\t"))
		{ cstr_erase(&tok, 0, 1); }

		while (cstr_startsWith(tok, " "))
		{ cstr_erase(&tok, 0, 1); }

		if (tok.data[0] != '\0')
		{
			// Erase open section
			if (tok.len > openSectionPos && tok.data[openSectionPos] == _parser.config.openSection)
			{
				if (!lexData.insideBlock) lexData.insideBlock = true;

				cstr_erase(&tok, openSectionPos, sizeof(_parser.config.openSection));
			}

			// Erase close section
			else if (tok.len > closeSectionPos && tok.data[closeSectionPos] == _parser.config.closeSection)
			{
				if (lexData.insideBlock) lexData.insideBlock = false;

				lexData.processingBlockParams = false;

				cstr_erase(&tok, closeSectionPos, sizeof(_parser.config.openSection));
			}
		}

		// Validate token
		const GOE_PairKeywordRegistry tokenValidation = goe_parser_isKeywordRegistered(&_parser, tok.data);

		// Error logic here
		if (!lexData.processingBlockParams && !tokenValidation.first)
		{
			// Unknown keyword error
			// Throw error if keyword was not found
			// If keyword and the type registered is not found
			CSTR err = cstr_init();

			cstr_set(&err, "No such keyword called '");
			cstr_add(&err, tok.data);
			cstr_add(&err, "'");

			lexError.code = GOE_PARSERERR_UNKNOWN_KW;
			lexError.message = GOE_sys_strdup(err.data);
			lexError.type = GOE_WESI_Type_Error;

			goe_wesi_push(lexError, _parser.config.directShowError); // Side-Note: If removing the push function, memory leak will happen
			cstr_destroy(&err);

			break;
		}

		else if (!tokenValidation.second.call)
		{
			if (!lexData.processingBlockParams)
			{
				lexError.code = GOE_PARSERERR_VALIDATION_FAIL;
				lexError.message = GOE_sys_strdup("Token Validation Failed");
				lexError.help = GOE_sys_strdup("Register the necessary calls pointing to a valid function");
				lexError.type = GOE_WESI_Type_Error;

				goe_wesi_push(lexError, _parser.config.directShowError);
			}

			continue;
		}

		// As there is no error, continue lexing:		
		else
		{
			callDataInfo.name = tok.data;
			callDataInfo.startEndBlockRange.first = accumulatedOpenSectionPos;
			callDataInfo.startEndBlockRange.second = accumulatedCloseSectionPos;
			callDataInfo.fullFile = fileDataResult.data;
			callDataInfo.initialIteratorLoop = i;

			// Get strings
			
			// SEARCH: params()
			// Get all params if insideBlock
			if (lexData.insideBlock)
			{
				freedParsedParams = goe_parser_parseParams(
						fileDataResult,
						tokenValidation,
						&dataParams,
						accumulatedOpenSectionPos,
						accumulatedCloseSectionPos,
						closeSectionChar,
						&lexData
				);

				if (!freedParsedParams.second)
				{
					char *retErrorMsg = "[UNKNOWN ERROR]";

					if (freedParsedParams.first.size >= 0)
						retErrorMsg = *(char**)cvec_get(&freedParsedParams.first, 0);

					lexError.code = GOE_PARSERERR_NOEND;
					lexError.message = strdup(retErrorMsg);
					lexError.help = GOE_sys_strdup("");
					lexError.type = GOE_WESI_Type_Error;

					goe_wesi_push(lexError, _parser.config.directShowError);

					__GOE_AS_NORMAL_LEX_CONTINUE;

					break; // Go out of the loop to exit
				}
			}

			// .call should NOT be NULL, hence, just assume it's not due to previous checks
			GOEParser_CallDataSender received = tokenValidation.second.call(callDataInfo, dataParams);

			// Failed when calling keyword module
			if (received.code > 0)
			{
				// TODO: DO ERRORS
				printf("The code...\n");
			}

			// Success when called keyword module
			else
			{
				if (received.requestCode == GOE_PARSER_CODE_DATA_MOD_FILE)
				{
					cstr_set(&fileDataResult, received.modFile);
					cvec_split(&fileDataResultCVEC, fileDataResult.data, " \n");

					accumulatedOpenSectionPos = received.charsIgnore.first;
					accumulatedCloseSectionPos = received.charsIgnore.second;

					i--;

					if (received.modFile)
					{ GOE_FREE(received.modFile); }

					__GOE_AS_NORMAL_LEX_CONTINUE;
					__GOE_PARSER_PROCESS_PARAMS;

					continue;
				}

				if (received.modFile)
				{ GOE_FREE(received.modFile); }
			}

			__GOE_PARSER_PROCESS_PARAMS;
		} // Main lexing

		__GOE_AS_NORMAL_LEX_CONTINUE;
	} // for(i)

	if (goe_wesi_hasWE() && !_parser.config.directShowError)
		goe_wesi_throw(GOE_WESI_Type_Error);

	printf("--- FILE ---\n%s\n", fileDataResult.data);

	GOE_FREE(openSectionChar);
	GOE_FREE(closeSectionChar);

	cvec_destroy(&fileDataResultCVEC);
 	cvec_destroy(&constantFileDataResult);
	cvec_destroy(&dataParams.first);

	cstr_destroy(&fileDataResult);
	cstr_destroy(&tok);
	cstr_destroy(&constantFileData);

	return errorData;
} // goe_parser_lex() function

