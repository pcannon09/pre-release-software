import sys

from pathlib import Path

from .stt.XTT import XTT
from .tts.XTS import XTS

def __execSTTTest(modelPath: Path = Path("./_models/default")) -> int:
	print("Start talking")

	engine = XTT("main-stt", modelPath)

	print(engine.listen())

	return 0

def __execTTSTest() -> int:
	talk = input("Enter a phrase: ")

	engine = XTS("main-tts")
	engine.speakText(talk)

	return 0

def main(argv: list, argc: int) -> int:
	arg = ""
	retCode = 0

	if (argc <= 1):
		arg = input("Execute STT (1) or TTS (2) test? ");
	
	else:
		arg = argv[1]

	if arg.lower() == "stt" or arg.lower() == "1":
		retCode = __execSTTTest()

	elif arg.lower() == "tts" or arg.lower() == "2":
		retCode = __execTTSTest();

	return retCode

if __name__ == "__main__":
	sys.exit(main(sys.argv, len(sys.argv)))

