from ..conf import *
from ..pip_modules import pyttsx3
from ..pip_modules.pyttsx3 import voice as pyttsx3Voice

from pathlib import Path
from typing import Optional, List

class XTS:
    """
    Offline text-to-speech class using pyttsx3.

    Example usage:
        xts = XTS(id="tts1", voice="english+f3", rate=150, volume=1.0)
        xts.speakText("Hello world!")
    """

    def __init__(
        self,
        id: str,
        voice: Optional[str] = None,
        rate: int = 150,
        volume: float = 1.0
    ):
        self.id = id
        self.engine = pyttsx3.init()
        self.rate = rate
        self.volume = volume

        # Configure engine
        self.engine.setProperty("rate", self.rate)
        self.engine.setProperty("volume", self.volume)

        # Set voice if provided
        if voice:
            availableVoices: List[pyttsx3Voice.Voice] = self.engine.getProperty("voices")
            matchingVoice = next((v for v in availableVoices if voice.lower() in v.name.lower()), None)

            if matchingVoice:
                self.engine.setProperty("voice", matchingVoice.id)
            else:
                print(f"[{self.id}] Warning: voice '{voice}' not found. Using default.")

        print(f"[{self.id}] TTS engine initialized. Rate: {self.rate}, Volume: {self.volume}")

    def speakText(self, text: str, block: bool = True):
        """
        Speak the provided text.

        Args:
            text: string to speak
            block: whether to block until speech is finished (default: True)
        """
        if not text:
            return

        self.engine.say(text)
        self.engine.runAndWait() if block else self.engine.startLoop(False)

    def stopSpeech(self):
        """Stop any ongoing speech immediately."""
        self.engine.stop()

    def setRate(self, rate: int):
        """Set speech rate (words per minute)."""
        self.rate = rate
        self.engine.setProperty("rate", self.rate)

    def setVolume(self, volume: float):
        """Set volume (0.0 to 1.0)."""
        self.volume = volume
        self.engine.setProperty("volume", self.volume)

    def setVoice(self, voiceName: str):
        """Set a specific voice by name substring."""
        availableVoices: List[pyttsx3Voice.Voice] = self.engine.getProperty("voices")
        matchingVoice = next((v for v in availableVoices if voiceName.lower() in v.name.lower()), None)
        if matchingVoice:
            self.engine.setProperty("voice", matchingVoice.id)
        else:
            print(f"[{self.id}] Warning: voice '{voiceName}' not found. Using current voice.")

