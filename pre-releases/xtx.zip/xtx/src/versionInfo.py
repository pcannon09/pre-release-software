class ReqInfo:
    VERSION: tuple = (0, 1, 0, "build")
    STANDARD: int = 20251215

