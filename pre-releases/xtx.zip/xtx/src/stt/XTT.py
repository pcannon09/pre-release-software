from ..conf import *
from ..pip_modules.vosk import Model, KaldiRecognizer
from ..pip_modules import sounddevice

from pathlib import Path
import queue
import json
from typing import Optional

class XTT:
    """
    Offline speech-to-text recognizer using Vosk.
    
    Example usage:
        xtt = XTT(id="mic0", modelDir=Path("/path/to/models/any-vosk-model"))
        text = xtt.listen()
    """

    def __init__(
        self,
        id: str,
        modelDir: Path,
        sampleRate: int = 16000,
        blockSize: int = 8000
    ):
        self.id = id
        self.modelDir = modelDir.resolve()
        self.sampleRate = sampleRate
        self.blockSize = blockSize

        # Load Vosk model
        if not self.modelDir.exists():
            raise FileNotFoundError(f"Vosk model directory not found: {self.modelDir}")
        self.model = Model(str(self.modelDir))

        # Recognizer instance
        self.recognizer = KaldiRecognizer(self.model, self.sampleRate)

        # Audio queue for streaming
        self._audioQueue: queue.Queue[bytes] = queue.Queue()

    def _audioCallback(self, inData, frames, time, status):
        """Internal sounddevice callback to push audio to queue."""
        if status:
            print("Audio status:", status)
        self._audioQueue.put(bytes(inData))

    def listen(self, timeout: Optional[float] = None) -> str:
        """
        Listen from the microphone and return recognized text.
        If timeout is provided, it stops listening after the given seconds.
        """

        text = ""

        # Open microphone stream
        with sounddevice.RawInputStream(
            samplerate=self.sampleRate,
            blocksize=self.blockSize,
            dtype='int16',
            channels=1,
            callback=self._audioCallback
        ):
            print(f"[{self.id}] Listening...")

            # Collect audio until a phrase is complete
            import time
            startTime = time.time()
            while True:
                if timeout and (time.time() - startTime) > timeout:
                    break

                data = self._audioQueue.get()
                if self.recognizer.AcceptWaveform(data):
                    result = json.loads(self.recognizer.Result())
                    text = result.get("text", "")
                    break

        return text

    def listenStreaming(self):
        """
        Generator version for streaming results.
        Yields partial text continuously as user speaks.
        """

        with sounddevice.RawInputStream(
            samplerate=self.sampleRate,
            blocksize=self.blockSize,
            dtype='int16',
            channels=1,
            callback=self._audioCallback
        ):
            print(f"[{self.id}] Streaming...")

            while True:
                data = self._audioQueue.get()
                if self.recognizer.AcceptWaveform(data):
                    result = json.loads(self.recognizer.Result())
                    yield result.get("text", "")

                else:
                    partial = json.loads(self.recognizer.PartialResult())

                    yield partial.get("partial", "")

