# Auto generated config file from `python-requirements`

import sys

sys.path.append("./src/pip_modules") # Add the modules path
