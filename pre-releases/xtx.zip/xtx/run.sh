#!/bin/bash

python3 -m src.main $@

