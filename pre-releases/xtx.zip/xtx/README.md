# XTX
## X To X (Anything To Something)
### 0.1.0 - 20251215

---

A little _crappy_ side-project to convert TTS and STT

## REQUIREMENTS

### Py-Req
* Need to be installed on the main system, optionally, use the executable:
**https://www.github.com/pcannon09/python-requirements**

### VOSK models:
Get vosk models here: **https://alphacephei.com/vosk/models**

Add them to any directory and use the API to use the software (or execute the main.py file as a module)

### Python +3.9 (Recommended +3.10)
Tested with **Python 3.13**
If you don't have the Python version requirement, please download here: **https://www.python.org**

---

