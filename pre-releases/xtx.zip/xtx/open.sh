#!/bin/bash

# PCANNON OPEN.SH v1.0S - FROM PCANNON PROJECT STANDARDS
# STANDARD: 20250608
# https://github.com/pcannon09/pcannonProjectStandards

defaultEdit="$1" # Set the default editor in parameter $1 (such as: code, vim, nvim, ...)

if [ "$1" == "" ]; then
	defaultEdit="nvim"
fi

$defaultEdit ./src/main.py $(find ./src/stt/*.py ./src/tts/*.py) ./src/conf.py

